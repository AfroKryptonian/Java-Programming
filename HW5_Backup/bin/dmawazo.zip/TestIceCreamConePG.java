import java.awt.Color;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.swing.JFrame;

/**
 *
 * @author David Mawazo
 *
 *         Andrew ID: dmawazo
 *
 *         On my honor, as a Carnegie-Mellon Africa student, I have neither
 *         given nor received unauthorized assistance on this work.
 * 
 *         This is the application class used to draw the Ice Cream Cone
 *         graphic, from the IceCreamConePG class. Prompt the user for
 *         attributes to change the number and color of the scoops.
 */

public class TestIceCreamConePG
{

	public static void main(String[] args) throws IOException
	{
		String str;
		String str2;
		String str3;
		String str4;

		String[] coords;
		String[] dimensions;

		JFrame frame = new JFrame();

		IceCreamConePG coneIce = new IceCreamConePG();

		frame.add(coneIce);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(800, 800);
		frame.setVisible(true);
		coneIce.setSize(frame.getSize());
		coneIce.setPreferredSize(frame.getSize());

		System.out.println(coneIce);

		BufferedReader keyboard = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the coordinates of the center as x,y: ");
		str = keyboard.readLine();

		while (!str.equals(""))
		{

			System.out.println("Enter the width and height: ");
			str2 = keyboard.readLine();

			System.out.println("Enter the number of scoops: ");
			str3 = keyboard.readLine();
			int scoopN = Integer.parseInt(str3);

			coneIce.clearScoop();

			for (int i = 0; i < scoopN; i++)
			{

				System.out.println("Enter the color of the scoop: ");
				str4 = keyboard.readLine();
				coneIce.addScoop(str4);

			}

			coords = str.split(",");
			dimensions = str2.split(",");

			int xCoord = Integer.parseInt(coords[0]);
			int yCoord = Integer.parseInt(coords[1]);

			int userWidth = Integer.parseInt(dimensions[0]);
			int userHeight = Integer.parseInt(dimensions[1]);

			coneIce.setNewLocation(xCoord, yCoord, userWidth, userHeight);

			coneIce.setWidthHeight(userWidth, userHeight);

			coneIce.repaint();
			System.out.println(coneIce);

			System.out.println("Enter the coordinates of the center as x,y: ");
			str = keyboard.readLine();
		}

	}

}
