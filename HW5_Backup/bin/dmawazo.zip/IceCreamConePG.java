import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.util.ArrayList;

/**
 *
 * @author David Mawazo
 *
 *         Andrew ID: dmawazo
 *
 *         On my honor, as a Carnegie-Mellon Africa student, I have neither
 *         given nor received unauthorized assistance on this work.
 * 
 *         This class extends the PositionalGraphic class, inherits its method
 *         in order to draw the Ice Cream Cone shape from instances of a
 *         TrianglePG and an arrayList of CirclePG objects with the coordinates
 *         of the bounding rectangle and sets it to new position.
 */

public class IceCreamConePG extends PositionalGraphic
{

	TrianglePG hTriangle = new TrianglePG();
	ArrayList<CirclePG> scoops = new ArrayList<CirclePG>();
	
	//Default constructor to set up the default position of the Ice cream cone

	public IceCreamConePG()
	{
		super();
		super.setDebugger(false);
		scoops.add(new CirclePG());

	}

	public void setNewLocation(int userX, int userY, int userWidth, int userHeight)
	{
		super.setNewLocation(userX, userY, userWidth, userHeight);
		setup();
	}

	public void setup()
	{

		hTriangle.setWidth(getWidth());
		hTriangle.setHeight(getHeight() * 3 / 4);
		hTriangle.setStartX(getStartX());
		hTriangle.setStartY(getStartY() + getHeight() / 2);
		hTriangle.setTriColor("yellow");

		int scoopX = (getBoundingRectangle().x + getBoundingRectangle().width / 2);
		int i = 0;
		for (CirclePG shape : scoops)
		{
			shape.setNewLocation(scoopX, (int) (getBoundingRectangle().y + ((i + 2) * getHeight() / 2) / (2 * scoops.size())),
					getWidth() / 2, getHeight() / 2);

			shape.setNewSize(getHeight() / (2 * scoops.size()));
			i++;
		}
	}

	// Method adds ice cream scoops to the cone
	public void addScoop(String scoopColor)
	{
		scoops.add(new CirclePG(ColorConverter.getColor(scoopColor)));

	}

	// clears the ice cream scoops from the drawing
	public void clearScoop()
	{
		scoops.clear();
	}

	public void paint(Graphics g)

	{
		setup();
		super.paint(g);

		for (CirclePG scoop : scoops)
		{
			scoop.paint(g);

		}
		
		hTriangle.paint(g);

	}

	public String toString()
	{
		return "Ice Cream Cone: " + super.toString() + "\nThe number of scoops are:" +scoops.size();
	}

}
